function showPrivacyPolicy() {
  $(window).on("load", function() {
    $("#privacyPolicyModal").modal("show");
  });
}
